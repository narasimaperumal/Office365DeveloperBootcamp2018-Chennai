import * as MicrosoftGraph from '@microsoft/microsoft-graph-types';

export interface IGraphTasksState {
  tasks: MicrosoftGraph.PlannerTask[];
}