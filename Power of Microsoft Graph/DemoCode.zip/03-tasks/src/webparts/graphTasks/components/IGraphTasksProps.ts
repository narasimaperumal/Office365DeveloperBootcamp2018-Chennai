import { MSGraphClient } from '@microsoft/sp-http';

export interface IGraphTasksProps {
  graphClient: MSGraphClient;
}
