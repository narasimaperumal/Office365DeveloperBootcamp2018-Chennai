declare interface IGraphTasksWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GraphTasksWebPartStrings' {
  const strings: IGraphTasksWebPartStrings;
  export = strings;
}
