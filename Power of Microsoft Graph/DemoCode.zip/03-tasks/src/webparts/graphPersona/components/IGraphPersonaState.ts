import * as MicrosoftGraph from '@microsoft/microsoft-graph-types';

export interface IGraphPersonaState {
  name: string;
  email: string;
  phone: string;
  image: string;
}