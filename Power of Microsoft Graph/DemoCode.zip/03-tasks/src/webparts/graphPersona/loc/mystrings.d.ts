declare interface IGraphPersonaWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GraphPersonaWebPartStrings' {
  const strings: IGraphPersonaWebPartStrings;
  export = strings;
}
