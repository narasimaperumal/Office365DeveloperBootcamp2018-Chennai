import * as MicrosoftGraph from '@microsoft/microsoft-graph-types';

export interface IGraphEventsListState {
  events: MicrosoftGraph.Event[];
}