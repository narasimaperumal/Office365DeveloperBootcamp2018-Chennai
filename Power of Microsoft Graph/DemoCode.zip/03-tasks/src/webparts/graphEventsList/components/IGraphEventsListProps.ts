import { MSGraphClient } from '@microsoft/sp-http';

export interface IGraphEventsListProps {
  graphClient: MSGraphClient;
}
