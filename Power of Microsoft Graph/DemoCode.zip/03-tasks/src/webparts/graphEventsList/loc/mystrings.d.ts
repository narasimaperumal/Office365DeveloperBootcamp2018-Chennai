declare interface IGraphEventsListWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GraphEventsListWebPartStrings' {
  const strings: IGraphEventsListWebPartStrings;
  export = strings;
}
